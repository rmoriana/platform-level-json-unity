﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GeneraRocas : MonoBehaviour {

    float platformPos=0;
    bool hasBeenCalled = false;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        platformPos += 0.02f;
	}

    public void generaRocas(float platPos)
    {
        if(hasBeenCalled == false)
        {
            hasBeenCalled = true;
            platformPos = platPos;
            Invoke("LluviaDeRocas", 20);
            Invoke("StopRocas", 20);
            InvokeRepeating("NuevaRoca", 0, 0.75f);
        }
       
    }

    private void StopRocas()
    {
        CancelInvoke("NuevaRoca");
    }

    private void NuevaRoca()
    {
        float posX;
        posX = Random.Range(platformPos, platformPos + 5);
        GameObject roca = Instantiate(Resources.Load("Prefabs/roca"), new Vector2(posX, 0), new Quaternion(0, 0, 0, 0)) as GameObject;
    }

    void LluviaDeRocas()
    {
        for (int i = 0; i < 10; i++)
        {

            GameObject roca = Instantiate(Resources.Load("Prefabs/roca"), new Vector2(platformPos+i, 0), new Quaternion(0, 0, 0, 0)) as GameObject;
        }
        
    }
}
