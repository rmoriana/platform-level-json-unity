﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalaControl : MonoBehaviour {

    GameObject player;
    Vector2 position;
    float speed = 0.1f;
	// Use this for initialization
	void Start () {
        player = GameObject.Find("player");
        position = player.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
        
        transform.position=  Vector2.MoveTowards(transform.position, position,speed);
	}

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.name == "player")
        {
            other.gameObject.GetComponent<ControlPlayer>().GetDamage(30);
        }
        else if(other.gameObject.tag != "goomba")
        {
            Destroy(this.gameObject);
        }
    }
}
