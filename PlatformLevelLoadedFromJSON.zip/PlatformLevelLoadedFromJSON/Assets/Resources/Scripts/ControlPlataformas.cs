﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControlPlataformas : MonoBehaviour {

    float dis = 33; //Distancia que recorren antes de parar
    float distRecorrida = 0; //Distancia recorrida
    float posX; //Posición inicial
    public float platformPosition;
    public bool inMoving;
	// Use this for initialization
	void Start () {
        posX = transform.position.x;
	}
	
	// Update is called once per frame
	void Update () {

		if(inMoving == true)
        {
            if(distRecorrida < dis)
            {
                transform.position = new Vector2(transform.position.x + 0.02f, transform.position.y);
                distRecorrida = transform.position.x - posX;
            }
            else
            {
                inMoving = false;
            }
            
        }
	}

    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.name == "player")
        {
            GameObject[] plataformasMoviles = GameObject.FindGameObjectsWithTag("PlataformaMovil");
            for (int i = 0; i < plataformasMoviles.Length; i++)
            {
                plataformasMoviles[i].GetComponent<ControlPlataformas>().inMoving = true;
            }
            platformPosition = transform.position.x;
            GameObject.Find("Main Camera").GetComponent<GeneraRocas>().generaRocas(platformPosition);
        }
    }

}
