﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SimpleJSON;

public class ParseadorJson : MonoBehaviour {

    public Sprite[] tilesBackground, tilesTerrain;
    int cuentaCapas = 0, cuentaAltura = 0;
    string capaName;
    int width, height;
    float posX, posY;
    bool isTerrain;
    JSONNode mapa;
    // Use this for initialization
    void Start () {
        
        //CARGAMOS EL JSON
        TextAsset mapText = Resources.Load("Sprites/mapaChuloJson") as TextAsset;
        //PARSEAMOS EL JSON
        mapa = JSON.Parse(mapText.text);
        tilesBackground = Resources.LoadAll<Sprite>("Sprites/BG");
        tilesTerrain = Resources.LoadAll<Sprite>("Sprites/terrain");

        readJson();
    }
	
	private void readJson()
    {
        //Cogemos en un array todas las capas para contarlas y acceder a ellas una por una
        JSONArray arrayCapas = mapa["layers"].AsArray;

        //Por cada capa hacemos la lectura de su contenido
        for (int i = 0; i < arrayCapas.Count; i++)
        {
            posX = 0;
            posY = 0;

            //Recupero el nombre de la capa y el valor de width y height de la capa correspondiente
            width = mapa["layers"][i]["width"].AsInt;
            height = mapa["layers"][i]["height"].AsInt;
            capaName = mapa["layers"][i]["name"];

            GameObject capa = new GameObject();
            capa.name = capaName;
            cuentaAltura = width; //Controla que la altura cambie cada vez que terminamos una fila

            //Esto sirve para saber que Tileset tiene que utilizar
            switch (capaName)
            {
                case "BackNubes": isTerrain = false; break;
                case "BackMontanias": isTerrain = false; break;
                case "BackCielo": isTerrain = false; break;
                default: isTerrain = true; break;
            }

            //Con esto consigo un array en el que cada posicion es el numero de tile de la capa en la que estamos
            JSONArray numerosTiles = mapa["layers"][i]["data"].AsArray;
            for (int j = 0; j < numerosTiles.Count; j++)
            {
                GameObject tile;

                //Tileset del terreno
                if (isTerrain == true)
                {
                    if(numerosTiles[j] != 0)
                    {
                        if (numerosTiles[j] == 17) //Esto arregla el problema de que la imagen del agua superficial es un poco mas pequeña
                        {
                            tile = Instantiate(Resources.Load("Prefabs/Tile"), new Vector2(posX, posY - 0.3f), new Quaternion(0, 0, 0, 0)) as GameObject;
                            tile.GetComponent<SpriteRenderer>().sprite = tilesTerrain[numerosTiles[j] - 1];
                            tile.GetComponent<SpriteRenderer>().sortingOrder = cuentaCapas;
                            tile.name = capaName;
                            tile.transform.parent = capa.transform;

                        }
                        else
                        {
                            tile = Instantiate(Resources.Load("Prefabs/Tile"), new Vector2(posX, posY), new Quaternion(0, 0, 0, 0)) as GameObject;
                            tile.GetComponent<SpriteRenderer>().sprite = tilesTerrain[numerosTiles[j] - 1];
                            tile.GetComponent<SpriteRenderer>().sortingOrder = cuentaCapas;
                            tile.name = capaName;
                            tile.transform.parent = capa.transform;
                            if (capaName == "BackTerreno") //Le añado transparencia porque es terreno de fondo
                            {
                                Color c = tile.GetComponent<SpriteRenderer>().color;
                                c.a = 0.8f;
                                tile.GetComponent<SpriteRenderer>().color = c;
                            }

                            switch (capaName)
                            {
                                case "BackTerreno": tile.AddComponent<ControlBackTerreno>(); break;
                                case "Terrain": tile.AddComponent<BoxCollider2D>(); break;
                                case "Plataformas":

                                    tile.AddComponent<BoxCollider2D>();
                                    if (tile.transform.position.x > 30)
                                    {
                                        tile.AddComponent<ControlPlataformas>();
                                        tile.tag = "PlataformaMovil";
                                    }
                                    break;
                                case "PlataformasCaen":
                                    tile.AddComponent<BoxCollider2D>();
                                    tile.AddComponent<ControlPlatCaen>();
                                    tile.tag = "PlatCaen";
                                    break;
                            }

                        }
                    }

                }
                else //ARRAY DEL BACKGROUND. HAY QUE RESTAR 19 A LA POSICION
                {
                    if(numerosTiles[j] != 0)
                    {
                        tile = Instantiate(Resources.Load("Prefabs/Tile"), new Vector2(posX, posY), new Quaternion(0, 0, 0, 0)) as GameObject;
                        tile.GetComponent<SpriteRenderer>().sprite = tilesBackground[numerosTiles[j] - 19];
                        tile.GetComponent<SpriteRenderer>().sortingOrder = cuentaCapas;
                        tile.name = capaName;
                        tile.transform.parent = capa.transform;

                        switch (capaName)
                        {
                            case "BackNubes": tile.AddComponent<ControlNubes>(); break;
                            case "BackMontanias": tile.AddComponent<ControlMontanias>(); break;
                        }
                    }
                }

                //Controlamos la posición en la que se colocan los tiles y bajamos la altura cuando llega al width maximo
                if (j == cuentaAltura - 1)
                {
                    posX = 0;
                    posY = posY - 1.25f;
                    cuentaAltura += width;
                }
                else
                {
                    posX += 1.25f;
                }
            }

            cuentaCapas++; //Para que la proxima capa se pinte por delante de la anterior
        }
        
    }
}
