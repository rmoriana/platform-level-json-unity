﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SierraControl : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void OnTriggerEnter2D(Collider2D other)
    {        
        if(other.gameObject.name == "player")
        {
            other.gameObject.GetComponent<ControlPlayer>().GetDamage(15);
        }
    }
}
